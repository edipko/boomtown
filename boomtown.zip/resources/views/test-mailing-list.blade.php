@extends('layouts.app')

@section('content')
    @livewire('mailing-list-signup')
@endsection
